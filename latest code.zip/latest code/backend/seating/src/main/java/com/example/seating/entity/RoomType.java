package com.example.seating.entity;

public enum RoomType {
    ROOM_8X8,  // 8 rows x 8 columns
    ROOM_8X12  // 8 rows x 12 columns
}
