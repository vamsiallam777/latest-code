package com.example.seating.entity;

public enum Role {
    ADMIN,
    STUDENT
}
